#pragma once
#include <string>
#include <vector>

enum class Command {
    CREATE_TRAM,
    TRAMS_IN_STOP,
    STOPS_IN_TRAM,
    TRAMS,
    UNKNOWN
};

Command parseCommand(const std::string& input);
void executeCommand(Command cmd, const std::vector<std::string>& args);
