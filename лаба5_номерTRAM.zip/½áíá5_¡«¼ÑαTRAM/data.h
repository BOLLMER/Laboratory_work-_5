#pragma once
#include <string>
#include <vector>
#include <map>
#include <set>

namespace Data {
    extern std::map<std::string, std::vector<std::string>> trams;
    extern std::map<std::string, std::set<std::string>> stops;

    void addTram(const std::string& tram, const std::vector<std::string>& stops);
    void printTramsForStop(const std::string& stop);
    void printStopsForTram(const std::string& tram);
    void printAllTrams();
}
