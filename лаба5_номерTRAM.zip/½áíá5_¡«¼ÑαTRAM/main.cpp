#include "command.h"
#include <iostream>
#include <sstream>
#include <vector>

int main() {
    std::string line;
    while (std::getline(std::cin, line)) {
        std::istringstream iss(line);
        std::vector<std::string> args;
        std::string token;
        while (iss >> token) {
            args.push_back(token);
        }
        if (args.empty()) continue;
        Command cmd = parseCommand(args[0]);
        executeCommand(cmd, {args.begin() + 1, args.end()});
    }
    return 0;
}
