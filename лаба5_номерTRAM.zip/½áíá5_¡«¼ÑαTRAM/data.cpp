#include "data.h"
#include <iostream>

namespace Data {
    std::map<std::string, std::vector<std::string>> trams;
    std::map<std::string, std::set<std::string>> stops;

    void addTram(const std::string& tram, const std::vector<std::string>& newStops) {
        trams[tram] = newStops;
        for (const auto& stop : newStops) {
            stops[stop].insert(tram);
        }
    }

    void printTramsForStop(const std::string& stop) {
        auto it = stops.find(stop);
        if (it == stops.end() || it->second.empty()) {
            std::cout << "Trans is absent\n";
            return;
        }
        for (const auto& tram : it->second) {
            std::cout << tram << " ";
        }
        std::cout << "\n";
    }

    void printStopsForTram(const std::string& tram) {
        auto it = trams.find(tram);
        if (it == trams.end()) {
            std::cout << "Stops is absent\n";
            return;
        }
        for (const auto& stop : it->second) {
            std::cout << "Stop " << stop << ": ";
            auto& tramsInStop = stops[stop];
            bool first = true;
            for (const auto& otherTram : tramsInStop) {
                if (otherTram != tram) {
                    if (!first) std::cout << " ";
                    std::cout << otherTram;
                    first = false;
                }
            }
            if (first) std::cout << "0";
            std::cout << "\n";
        }
    }

    void printAllTrams() {
        if (trams.empty()) {
            std::cout << "Trans is absent\n";
            return;
        }
        for (const auto& [tram, stops] : trams) {
            std::cout << "TRAM " << tram << ": ";
            for (const auto& stop : stops) {
                std::cout << stop << " ";
            }
            std::cout << "\n";
        }
    }
}
