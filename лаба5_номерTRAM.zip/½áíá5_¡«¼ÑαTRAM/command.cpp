#include "command.h"
#include "data.h"
#include <iostream>

Command parseCommand(const std::string& input) {
    if (input == "CREATE_TRAM") return Command::CREATE_TRAM;
    if (input == "TRAMS_IN_STOP") return Command::TRAMS_IN_STOP;
    if (input == "STOPS_IN_TRAM") return Command::STOPS_IN_TRAM;
    if (input == "TRAMS") return Command::TRAMS;
    return Command::UNKNOWN;
}

void executeCommand(Command cmd, const std::vector<std::string>& args) {
    switch(cmd) {
        case Command::CREATE_TRAM:
            if (args.size() < 2) {
                std::cout << "Error: Not enough arguments\n";
                return;
            }
            Data::addTram(args[0], {args.begin() + 1, args.end()});
            break;
        case Command::TRAMS_IN_STOP:
            if (args.empty()) {
                std::cout << "Error: Missing stop name\n";
                return;
            }
            Data::printTramsForStop(args[0]);
            break;
        case Command::STOPS_IN_TRAM:
            if (args.empty()) {
                std::cout << "Error: Missing tram name\n";
                return;
            }
            Data::printStopsForTram(args[0]);
            break;
        case Command::TRAMS:
            Data::printAllTrams();
            break;
        default:
            std::cout << "Unknown command\n";
    }
}
